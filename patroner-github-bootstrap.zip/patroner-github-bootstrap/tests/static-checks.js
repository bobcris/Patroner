const fs = require('node:fs');
const html = fs.readFileSync('app/index.html', 'utf8');
const checks = [
  ['version marker', /PATRONER\s*<span[^>]*>v1\.20<\/span>/i],
  ['XS–XXL chart', /XS:\{waist:60,hip:84,depth:18,length:60\}[\s\S]*XXL:\{waist:96,hip:120,depth:23,length:60\}/],
  ['deterministic landmark function', /function deriveLandmarks\(pattern\)/],
  ['size progression audit', /function runSizeProgressionAudit\(\)/],
  ['geometry validator', /function validatePatternGeometry\(/],
  ['SVG export', /function svgExport\(/],
  ['tiled PDF export', /function tiledPdf\(/]
];
let failed = 0;
for (const [label, re] of checks) {
  const ok = re.test(html);
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${label}`);
  if (!ok) failed++;
}
if (failed) process.exitCode = 1;
else console.log(`PASS: ${checks.length}/${checks.length} static checks.`);
