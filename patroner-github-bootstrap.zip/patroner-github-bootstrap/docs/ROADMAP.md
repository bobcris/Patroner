# Patroner technical roadmap

## Current baseline: v1.20
- Single-file, tablet-friendly browser prototype.
- Provisional XS–XXL body measurement chart and custom measurements.
- Experimental quarter-skirt draft, SVG and tiled PDF exports.
- Geometry diagnostics and deterministic draft landmark export.

## Next engineering milestones
1. Extract pure drafting and geometry functions from the UI into a testable module.
2. Add unit tests for unit conversion, measurement validation, polygon area, intersections, dart arithmetic, and export geometry.
3. Define a documented base skirt block with explicit drafting assumptions and construction ease.
4. Specify point-level grade rules relative to a base size; do not label these production grading until validated against a trusted block.
5. Add seam-length comparison, dart closure checks, and offset-curve tests.
6. Validate with a qualified patternmaker and physical toile before claiming fit or production readiness.

## Known limitations
- The size chart is provisional, not a universal sizing standard.
- The draft is an experimental quarter-skirt panel, not a validated commercial block.
- Static checks and syntax checks do not prove fit, construction correctness, or print accuracy.
- No browser automation or physical fitting has been completed.
