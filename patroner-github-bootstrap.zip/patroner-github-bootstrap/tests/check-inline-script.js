const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync('app/index.html', 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/gi)].map(m => m[1]);
if (!scripts.length) throw new Error('No inline JavaScript script found');
for (const [i, script] of scripts.entries()) new vm.Script(script, { filename: `inline-script-${i + 1}.js` });
console.log(`PASS: JavaScript syntax parsed (${scripts.length} inline script(s)).`);
