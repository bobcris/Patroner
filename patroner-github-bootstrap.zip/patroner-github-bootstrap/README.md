# Patroner Pattern Studio

Tablet-friendly, local browser prototype for experimental sewing-pattern drafting. The app runs in the browser and does not upload measurement data.

## Run locally
Open `app/index.html` in a modern browser. No build step or package installation is required.

## Development checks
Requires Node.js 18 or newer. From the repository root run:

```sh
npm test
```

## Current status
Baseline imported from Patroner v1.20. Includes a provisional XS–XXL chart, custom measurements, experimental quarter-skirt draft, SVG/PDF/CSV exports, and geometry diagnostics.

**Not production-ready:** the size chart is provisional and the draft has not been validated as a professional garment block. Automated syntax/static checks do not establish fit. See `docs/ROADMAP.md` and `docs/TEST_REPORT_v1.20.md`.
